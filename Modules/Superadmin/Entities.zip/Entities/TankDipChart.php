<?php

namespace Modules\Superadmin\Entities;

use Illuminate\Database\Eloquent\Model;

class TankDipChart extends Model
{
    protected $guarded = ['id'];
}
