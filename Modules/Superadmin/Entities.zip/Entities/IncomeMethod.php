<?php

namespace Modules\Superadmin\Entities;

use Illuminate\Database\Eloquent\Model;

class IncomeMethod extends Model
{
    protected $fillable = [];

    protected $guarded = ['id'];
}
