<?php

namespace Modules\Superadmin\Entities;

use Illuminate\Database\Eloquent\Model;

class Referral extends Model
{
    protected $fillable = [];

    protected $guarded = ['id'];
}
