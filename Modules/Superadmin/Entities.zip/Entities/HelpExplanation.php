<?php

namespace Modules\Superadmin\Entities;

use Illuminate\Database\Eloquent\Model;

class HelpExplanation extends Model
{
    protected $fillable = [];

    protected $guarded = ['id'];
}
