<?php

namespace Modules\Superadmin\Entities;

use Illuminate\Database\Eloquent\Model;

class TankDipChartDetail extends Model
{
    protected $guarded = ['id'];
}
